// 提示信息仅在开发环境生效
import { createI18n, LocaleMessages, VueMessageType } from 'vue-i18n'
import store from '@/store'

const files= import.meta.globEager('./modules/*.ts')

let messages: LocaleMessages<VueMessageType> = {}
Object.keys(files).forEach((c: string) => {
  const module = files[c].default
  const moduleName: string = c.replace(/^\.\/(.*)\/(.*)\.\w+$/, '$2')
  messages[moduleName] = module
})

const lang = store.state.app.lang || navigator.userLanguage || navigator.language // 初次进入，采用浏览器当前设置的语言，默认采用中文
const locale = lang.indexOf('en') !== -1 ? 'en' : 'zh-cn'

const i18n = createI18n({
  legacy: true,
  locale: locale,
  fallbackLocale: 'zh-cn',
  messages
})

document.getElementsByTagName('html')[0].setAttribute('lang', locale)

export default i18n